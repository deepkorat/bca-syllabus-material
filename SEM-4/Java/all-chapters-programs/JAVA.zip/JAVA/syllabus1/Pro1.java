//Write a program to evaluate simple interest of a given principle, rate and time.n

class Pro1{

    public static void main(String args[])
    {
        int r = 5;
        int n = 5;
        int p = 1000;

        int i;
        i = (p*r*n)/100;

        System.out.println("The simple interest is => "+i);
    }
}
