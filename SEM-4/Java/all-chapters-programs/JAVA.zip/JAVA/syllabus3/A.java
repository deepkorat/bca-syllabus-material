package pack1;

public class A
{
	public int age = 20;
	public void show_age()
	{
		System.out.println("The age is  : " + age);
	}
}