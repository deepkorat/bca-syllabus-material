package pack2;
import pack1.A;

public class B
{
	public void check()
	{
	A obja = new A();
	obja.show_age();
    }
}