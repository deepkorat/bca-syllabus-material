import pack2.B;

class Pro3
{
	 public static void main(String[] args) {
	 	B objb = new B();
	 	objb.check();
	 }
}