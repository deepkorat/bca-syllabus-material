import p.pro1;

public class p 
{
	public static void main(String[] args) {
		pro1 objp = new pro1();
		int n = objp.findmax(10,20,30);
		System.out.println("The maximum number is -> "+n);
	}
}