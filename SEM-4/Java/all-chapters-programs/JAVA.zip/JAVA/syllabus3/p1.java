/*Write a program that creates three different classes in three different packages 
and access them from default package. All the three packages should be at the 
same level.*/

package A;

public class p1
{
	public void show()
	{
		System.out.println("This is the first package");
	}
}