package B;

public class p2
{
	public void show()
	{
		System.out.println("This is the Second package");
	}
}