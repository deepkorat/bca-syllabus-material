package C;

public class p3
{
	public void show()
	{
		System.out.println("This is the Third package");
	}
}