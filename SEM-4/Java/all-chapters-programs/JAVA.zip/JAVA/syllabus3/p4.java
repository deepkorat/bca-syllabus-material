package D;

import 

public class p4
{
	public void show()
	{

      System.out.println("THis is default package");
	}
}
