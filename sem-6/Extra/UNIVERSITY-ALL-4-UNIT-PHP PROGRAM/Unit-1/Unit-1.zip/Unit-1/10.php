<?php
	$no=array(12,27,11,34,27,12,65,27,84,12);
$length = count(array_keys($no, 27));
echo $length;
	
?>