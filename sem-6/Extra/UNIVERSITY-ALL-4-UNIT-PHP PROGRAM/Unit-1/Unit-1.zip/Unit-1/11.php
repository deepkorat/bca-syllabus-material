<?php

$v1 = 3;
$v2 = 2;

if($v1==$v2)
{
    $ans=($v1+$v2)*3;
    echo "<h1>".$ans."</h1>";

}
else
{
    $ans=($v1+$v2);
    echo "<h1>".$ans."</h1>";
}
?>