<?php
	echo "by using echo"."<br>";
	print "by using print";
	//comments(single line)
	/*multiline*/
?>