<?php
	$student=array(
		"name"=>"smit",
		"marks"=>"67",
		"std"=>"std-8");

echo "student name is " . $student["name"]."<br>";
echo "student mark is " . $student["marks"]."<br>";
echo "student standard is " . $student["std"];
?>