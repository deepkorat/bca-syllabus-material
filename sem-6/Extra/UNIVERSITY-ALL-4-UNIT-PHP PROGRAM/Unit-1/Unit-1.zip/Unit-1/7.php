<?php
	function func1()
	{
	echo "this is first function<br>";
	}
	function func2($x){
	echo "value of x is $x";
	}

func1();
func2(12);
?>