<?php
	$a=array("pqr","abc","xyz");
	// $a=array(10,2,50,66,78);
	if(sort($a)){
    print_r($a);
}
echo "<br>";

if (rsort($a)) {
	print_r($a);
}
?>