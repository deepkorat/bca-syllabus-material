<?php  
// Database configration.....
$host = "localhost";
$user = "root";
$pass = "";
$database = "db1";
$con = mysqli_connect($host,$user,$pass,$database);
?>