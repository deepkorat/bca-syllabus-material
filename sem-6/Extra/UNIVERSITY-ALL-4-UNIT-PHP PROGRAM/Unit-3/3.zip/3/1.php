<?php 

$Name = $_GET['name'];
echo "Welcome ".$Name;

?>