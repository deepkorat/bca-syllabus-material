<?php 

$Name = $_GET['name1'];

echo "Welcome ".$Name;

?>