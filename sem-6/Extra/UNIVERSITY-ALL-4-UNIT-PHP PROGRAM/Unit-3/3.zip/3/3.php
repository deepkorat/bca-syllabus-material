<?php 
$x = $_GET['str'];
echo strtoupper($x)
?>