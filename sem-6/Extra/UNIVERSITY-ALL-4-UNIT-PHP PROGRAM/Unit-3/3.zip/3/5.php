<?php 
if(isset($_GET['val'])){
	echo $_GET['val'];
}
if(isset($_GET['val1'])){
	echo $_GET['val1'];
}
?>