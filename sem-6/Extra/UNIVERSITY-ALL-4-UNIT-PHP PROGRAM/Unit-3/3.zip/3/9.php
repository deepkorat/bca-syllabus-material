<?php
echo "Welcome , This is XMLHttpRequest...";
?>