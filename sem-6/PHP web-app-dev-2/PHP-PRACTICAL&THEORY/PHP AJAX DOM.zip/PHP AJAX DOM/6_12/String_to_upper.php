<!DOCTYPE html>
<html>
<body>

<p>Click the button to convert the string to uppercase letters.</p>

<button onclick="myFunction()">Try it</button>

<p id="demo"></p>

<script>
function myFunction() {
  var str = "Hello Class!";
  var res = str.toUpperCase();
  document.getElementById("demo").innerHTML = res;
}
</script>

</body>
</html>