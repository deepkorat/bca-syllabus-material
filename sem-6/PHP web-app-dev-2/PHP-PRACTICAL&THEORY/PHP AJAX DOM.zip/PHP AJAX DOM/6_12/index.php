<html>
	<head>
		<script type="text/JavaScript" src="listajax.js"></script>

	</head>
	<body>
	Choose the Category:<br>
	<select id="Category" onchange="itemdisplay()">
		<option value="CAMERA">Camera</option>
		<option value="MOBILE">Mobile</option>
		<option value="PEN DRIVE">Pen Drive</option>
		<option value="BOOKS">Books</option>
		<option value="MOUSE">Mouse</option>
	</select><br><br>
	
	<div id="info"></div>
	</body>
</html>
