<?php
	echo "The category selected is:".$_GET['Category'];
?>