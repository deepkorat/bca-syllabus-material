<?php
	echo "Welcome  ".$_GET['username']." For Learning AJAX";
?>