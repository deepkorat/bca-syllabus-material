<html>
<head>
<script language="JavaScript" type="text/JavaScript">

function showdata(user) 
{
    if (user == "") {
        document.getElementById("txtHint").innerHTML = "";
        return;
    } 
    else 
    {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } 
	else 
	{
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        
	
	var file="ajaxdata1.php?username=";

    xmlhttp.open("GET",file+user,true);

	xmlhttp.onreadystatechange = function() 
	{
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) 
	    {

		var content=xmlhttp.responseText;
		
		if(content)
		{
		
		document.getElementById("info").innerHTML = content.toUpperCase();
		}
            }
        }

        xmlhttp.send();
    }
}
</script>
</head>
<body>

<form>

Enter your Name:<input type="text" onkeyup="showdata(this.value)"/>

<div id="info"></div>
</form>


</body>
</html>