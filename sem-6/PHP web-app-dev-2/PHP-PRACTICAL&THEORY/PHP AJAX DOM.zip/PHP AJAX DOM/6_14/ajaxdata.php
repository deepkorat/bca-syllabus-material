<?php
	$con=mysqli_connect("localhost","root","");
	mysqli_select_db($con,"shopping");
	
	$cat=$_GET["Category"];
	
	$sql="select * from products WHERE Category like '$cat'";
	
	$query=mysqli_query($con,$sql) or die (mysql_error());
	
	echo '<table >';
	echo '<th>Item Code</th><th>Item Name</th><th>Quantity</th><th>Price</th>';
	
	while($r=mysqli_fetch_array($query))
	{
		echo '<tr><td>'.$r["item_code"].'</td><td>'.$r["item_name"].'</td><td>'.$r["quantity"].'</td><td>'.$r["price"].'<td></tr>';
	}
	echo '</table>';
	echo '<img src="linux.jpg">';
?>