<html>
	<head>
		<script type="text/JavaScript" src="ajaxform.js"></script>

	</head>
	<body>
	
	<div id="links">
	<a href="javascript:showdata('Camera')">Camera</a>
	<a href="javascript:showdata('Mobile')">Mobile</a>		
	</div>
	<div id="content"></div>
	</body>
</html>
