function makeRequestObject()
{

	var xmlhttp=false;

       try {

       xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");

        } catch (e) 
		{

        try {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");

        } catch (E) 
		{

		xmlhttp = false;

		}

      }

      if (!xmlhttp && typeof XMLHttpRequest!="undefined")
	 {

      xmlhttp = new XMLHttpRequest();

      }

      return xmlhttp;

 }

function display()
{
		  
		
      var xmlhttp=makeRequestObject();

      ControlsArray=document.getElementsByTagName("input");

      var fooditms="";

      var drinkitms="";

      for(var i=0; i< ControlsArray.length; i++)

      {

		if(ControlsArray[i].type=="checkbox" && ControlsArray[i].checked)
		{
			fooditms+=ControlsArray[i].value + ",";
						
		}

        if(ControlsArray[i].type=="radio" && ControlsArray[i].checked)
       {
			drinkitms+=ControlsArray[i].value + "";
	   }

      }
	
	xmlhttp.open("GET", "checkboxradiodata.php?+SelectedDrink="+drinkitms+"&SelectedFood="+fooditms, true);

      xmlhttp.onreadystatechange=function() 
	  {

      if (xmlhttp.readyState==4 && xmlhttp.status == 200) {

      var content = xmlhttp.responseText;

      if( content ){

      document.getElementById("info").innerHTML = content;

      }

      }

      }

      xmlhttp.send(null)

      }