<?php

$food=$_GET["SelectedFood"];

$drink=$_GET["SelectedDrink"];

if($drink=="")

{

echo "You have not selected any drink <br><br>";

}

else

{

echo "The drink selected is : " . $drink . "<br><br>";

}

if($food=="")

{

echo "You have not selected food <br><br>";

}

else

{

echo "The types of Food selected are : " . $food . "<br><br>";

}

?>