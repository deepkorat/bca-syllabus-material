<html>

<head>

<script language="JavaScript" type="text/JavaScript" src="checkboxradioajax.js"></script>

</head>

<body>

Choose one : <br>

<input type="radio" name="drink" value ="Hot Coffee" onClick="display()"> Hot Coffee  <br>

<input type="radio" name="drink" value ="Cold Coffee" onClick="display()"> Cold Coffee <br>

<input type="radio" name="drink" value ="Soft Drink" onClick="display()"> Soft Drink <br><br>

Choose all the options that you want to have : <br>

<input type="checkbox" name="food" value ="Hot Dog" onClick="display()"> Hot Dog  <br>

<input type="checkbox" name="food" value="Pizza" onClick="display()">Pizza   <br>

<input type="checkbox" name="food" value="Noodles" onClick="display()">Noodles  <br>

<input type="checkbox" name="food" value="Chips" onClick="display()">Chips  <br><br>

<div id="info"></div>

</body>

</html>