function showdata()
{
	obld=document.createElement("I");
	
	omsg=document.createTextNode("We provide many courses");
	
	obld.appendChild(omsg);
	
	getdiv=document.getElementById("info");
	
	getdiv.appendChild(obld);
}