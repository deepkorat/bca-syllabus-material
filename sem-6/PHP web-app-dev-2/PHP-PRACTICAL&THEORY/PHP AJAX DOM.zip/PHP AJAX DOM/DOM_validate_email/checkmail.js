/*
pattern forming for regular expression

//
/()/
/(^\w)/   		One or nore alphanumeric characters
/(^\w + \@\w)/		Then it should be followed by "@" and again one or more alphanumeric characters
/(^\w + \@\w +\.\w+)/   Then it should be follwoed by "." and again one or more alphanumeric characters

*/
function validatefield(obj)
{
	var div=document.getElementById("emailmsg");
	div.style.color="red";

	if(div.hasChildNodes())//its used to remove the first message
	{
		div.removeChild(div.firstChild);
	}
	regex=/(^\w+\@\w+\.\w+)/;
	match=regex.exec(obj.value);
	
	if(!match)
	{
		div.appendChild(document.createTextNode("Invalid Email"));
		obj.focus();
	}
	else
	{
		div.appendChild(document.createTextNode("Valid Email..."));
		obj.focus();
	}
	
}