<!--
Behaves abnormmal in chrome and works perfectly in MOZILLA
-->
<html>
<script language="JavaScript" type="text/JavaScript" src="checkmail.js">
</script>
<body>
Enter Email ID: <input type="text" size="20" name="emailid" onblur="validatefield(this)">
<div id="emailmsg">
</body>
</html>