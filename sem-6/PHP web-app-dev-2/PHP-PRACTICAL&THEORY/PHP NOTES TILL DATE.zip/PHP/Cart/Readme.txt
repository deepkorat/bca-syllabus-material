Step 1: Create a database names demo.

Step 2: Import the table products into the database demo

Enjoy the Cart Application.
