<!--
	4.3 Getting information from the user & searching by ID
	
	Also searching by Address or any other field can be done
-->
<body>
<form action="Deletecustomer.php" method="POST">
<fieldset>
<legend>Enter User ID of the Record to be DELETED</legend>
<table>
<tr>
	<td>ID:</td>
	<td><input type="text" size=20 name="id"></td>
</tr>
<tr>
	<td><input type="SUBMIT" name="submit" value="DELETE" onclick=del()></td>
	<td><input type="reset" value="CANCEL"></td>
</tr>
</table>
</fieldset>
<form>

