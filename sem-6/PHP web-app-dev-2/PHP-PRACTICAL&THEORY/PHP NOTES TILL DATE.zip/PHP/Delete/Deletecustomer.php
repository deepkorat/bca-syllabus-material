<!--
4.7 Deleting records from the table
-->
<?php


/*Step-1 Establishing a connection with the MySQL Server*/

	$connect=mysqli_connect("localhost","root","")or die("Please check the database connection");

/*Step-2 Selecting the database*/

	mysqli_select_db($connect,"shopping");

/*Step-3 Getting the criteria..*/	
	
	$uid=$_POST["id"];

/*Step-4 Writing the SQL statements for DELETING the record*/

	$query="DELETE from customer where id like '$uid'";

/*Step-5 Executing the SQL Statement to DELETE the record(s)*/

	
	$result=mysqli_query($connect,$query) or die(mysqli_error($connect));
	
	$num=mysqli_affected_rows($connect);

	if($num>0)

	echo "Record no: ".$uid." Deleted from the database";

	else

	echo "Record to be deleted not found";
		

?>