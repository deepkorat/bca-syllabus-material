<!--
	Here the method GET OR POST should be the same on the receiving PHP page OR VICE VERSA
-->
<form action="display.php" method="POST">
<table>
<tr>
	<td>Name:</td>
	<td><input type="text" name="name"></td>
</tr>
<tr>
		
	<td>Age:</td>
	<td><input type="text" name="age"></td
<tr>
<tr>
	<td><input type="SUBMIT"></td>
</tr>
</table>
<form>