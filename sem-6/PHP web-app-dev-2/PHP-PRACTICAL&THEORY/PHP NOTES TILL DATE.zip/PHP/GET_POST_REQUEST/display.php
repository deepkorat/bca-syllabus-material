<!--The $_POST array is an array which collects the values sent from a form using HTTP POST method
Below given PHP code retrives the data from the main form.(Main.php)

IF we are not aware of the HTP method used by the source PHP script, it is wise to access the information
using a $_REQUEST array.

MERIT:- 1)Varibles sent with HTTP POST are not shown in URL
	2)Variables have no length limit.
-->


<?php
	echo "Welcome:".$_REQUEST["name"]."<br>";
	echo "Your age is:".$_REQUEST["age"];
?>