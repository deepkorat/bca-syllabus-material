/*
	Single page code for Insert and Display PHP.
*/
<?php

$connect = mysqli_connect("localhost","root","");

mysqli_select_db($connect,"test");//db_name test

//retrieve email id entered by user and store in $eid. and so on for other values
 
$eid=$_POST['eid'];
$p=$_POST['pass'];
$m=$_POST['mob'];
$add=$_POST['add'];

//checked whether user clicked on INSERT button
 
if(isset($_POST['ins']))
{

//table name/structure stuinfo(email(PK),password,mobile,address)

$sql="INSERT INTO stuinfo values('$eid','$p','$m','$add')";
 
mysqli_query($connect,$sql);

echo "<br><br><b>Record saved in the Student information Table</b></br>";

}
 
//checked whether user clicked on display button
 
if(isset($_POST['disp']))
{
$res=mysqli_query($connect,"SELECT * FROM stuinfo");

echo "<table border='1'>";

echo "<tr><th>EMP_Id</th><th>Password</th><th>Mobile</th><th>Address</th></tr>"; 
 
while($row=mysqli_fetch_array($res))
{
	extract($row);
	echo "<tr>";
		echo "<td>";
		echo $email;	//field names from the database table.
 		echo "</td>";

		echo "<td>";
		echo $password;	//field names from the database table.
 		echo "</td>";

		echo "<td>";	
		echo $mobile;	//field names from the database table.
 		echo "</td>";		

		echo "<td>";
		echo $address;	//field names from the database table.
 		echo "</td>";
	echo "</tr>\n";
}
echo "</table>\n";
} 
?>