<body>
 
<form  method="POST" action="ins_show.php">
 
<table width="419" border="1"> 
 <tr>    
<td width="173">Enter your email </td>
  <td width="230"><input type="email"  name="eid"/>
 
</td>  </tr>  <tr> 
 
   <td>Password</td>  
 
<td><input type="password"  name="pass"/></td> 
 
</tr>  <tr>    <td>Mobile</td> 
 
   <td><input type="text"  name="mob"/></td>
 
  </tr> 
 
 <tr>   
 <td>Address</td> 
  
 <td><textarea name="add"></textarea></td> 
 
 </tr> 
 
  	<tr> 
 		<td colspan="2" align="center">	<input type="submit" name="ins" value="Insert"/>			
 
<input type="submit" name="disp" value="SHOW"/>	
 
</tr>
 
</table>
 
</form>
 
</body>
 
</html>