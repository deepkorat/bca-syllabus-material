<!--
4.6 Searching records from the table
Main page search.php
-->
<?php


/*Step-1 Establishing a connection with the MySQL Server*/

	$connect=mysqli_connect("localhost","root","")or die("Please check the database connection");

/*Step-2 Selecting the database*/

	mysqli_select_db($connect,"shopping");

/*Step-3 Getting the criteria..*/	
	
	$uid=$_POST["id"];
#	echo $uid;//only for the purpose of testing

/*Step-4 Writing the SQL statements for searching the record*/

	$query="select id,name,address,img_url from customer where id='$uid'";
	
	
/*Step-4 Executing the SQL Statement*/

	$result=mysqli_query($connect,$query) or die(mysqli_error($connect));

/*Step-5 Fetching one row at a time from the result set and displaying it one by one*/

	echo "<table border=1>";
		echo "<th>ID</th><th>NAME</th><th>ADDRESS</th><th>Personal Image</th>\n";
	
		while($row=mysqli_fetch_array($result))
		{
			extract($row);

				echo "<tr>";
				echo "<td>";
				echo $id;
				echo "</td>";
				
				echo "<td>";
				echo $name;
				echo "</td>";
				
				echo "<td>";
				echo $address;
				echo "</td>";
				
				echo "<td>";
				echo "<img src='$img_url' height=75 width=75 alt='Image not available'>";
				echo "</td>";

				echo "</tr>";
		}
	echo "</table>";

$num_row_fetched=mysqli_num_rows($result);

/*Used to display the total number of rows returned*/

echo "Total number of Records Fetched are:".$num_row_fetched;

?>