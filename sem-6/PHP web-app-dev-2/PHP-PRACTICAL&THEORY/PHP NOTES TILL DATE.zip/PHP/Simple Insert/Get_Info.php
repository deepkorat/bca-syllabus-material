<!--
	4.3 Getting information from the user
-->

<form action="insert_record.php" method="POST">
<fieldset>
<legend>Personal Information</legend>
<table>
<tr>
	<td>ID:</td>
	<td><input type="text" size=20 name="id"></td>
</tr>
<tr>
	<td>Name:</td>
	<td><input type="text" size=20 name="name"></td>
</tr>
<tr>
		
	<td>Address:</td>
	<td><input type="text" size=20 name="add"></td
<tr>
<tr>
	<td><input type="SUBMIT" name="submit" value="SUBMIT"></td>
	<td><input type="reset" value="CANCEL"></td>
</tr>
</table>
</fieldset>
<form>