<!--
	4.4 Inserting records in the table

This code can be written in "get_info.php" if you dont want re-direct to antoher page
also in action paramter will contain the same page name.
-->

<?php

/*Step-1 Establishing a connection with the MySQL Server*/

	$connect=mysqli_connect("localhost","root","") or die("Please check the database server connection");

/*Step-2 Selecting the database*/

	mysqli_select_db($connect,"shopping");

/*Step-3 Collecting the information to be stored in the table*/

	$id=$_POST["id"];
	$name=$_POST["name"];
	$address=$_POST["add"];
	
	#  $myusername = mysqli_real_escape_string($db,$_POST['username']);
    # $mypassword = mysqli_real_escape_string($db,$_POST['password']); 
    

/*Step-4 Wrting SQL statements for inserting the record*/
	
	$sql="Insert into customer(id,name,address) VALUES('$id','$name','$address')";

	//$sql_1="Insert into login(User_id,Password) VALUES('$id','$pass')";	

/*Step-5 Executing the SQL statement*/
	$result=mysqli_query($connect,$sql) or die(mysqli_error($connect));

//	$result_1=mysql_query($sql_1) or die(mysql_error());

	echo "Record is saved";
?>