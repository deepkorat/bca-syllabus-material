<!--
4.7 Updating records from the table depending upon criteria
-->
<?php


/*Step-1 Establishing a connection with the MySQL Server*/

	$connect=mysqli_connect("localhost","root","")or die("Please check the database connection");

/*Step-2 Selecting the database*/

	mysqli_select_db($connect,"shopping");

/*Step-3 Getting the criteria..*/	
	
	$uid=$_POST["id"];
	$address_data=$_POST["address"];

/*Step-4 Writing the SQL statements for UPDATING the record*/

		$query="UPDATE customer SET ADDRESS='$address_data' WHERE id='$uid'";

/*Step-4 Executing the SQL Statement to DELETE the record(s)*/

	
	mysqli_query($connect,$query) or die(mysqli_error($connect));
	
	$num=mysqli_affected_rows($connect);

	#if($num>0)

	echo "Record no: ".$uid." Updated in the database <br>";
	echo "Number of records updated:".$num;

	#else

	#echo "No record to be found";
?>