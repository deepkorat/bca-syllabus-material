<html>
	<head>
	<script language="JavaScript" type="text/JavaScript" src="checkmail.js">
	</script>
	</head>
	<body>
	Enter E-Mail ID: <input type=""text" name="emailid" onblur="validatefield(this)">
	<div id="emailmsg">
	</body>
</html>
