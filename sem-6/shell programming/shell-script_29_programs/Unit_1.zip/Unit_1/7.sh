who -S | grep [s]*
